import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

const Home = () => {

    let [data,setData] = useState([])

    useEffect(()=>{
        axios.get("http://localhost:3030/users")
        .then(res => setData(res.data))
        .catch(err => console.log(err))
    },[])
    console.log(data)

  return (
    <div>
      <h1>User Data</h1>
      <table border={1} cellPadding={5} cellSpacing={10} style={{borderCollapse:"collapse"}}>
        <thead>
            <tr>
                <td>ID</td>
                <td>Name</td>
                <td>Phone</td>
                <td>Actions</td>
            </tr>
        </thead>
        <tbody>
            {
                data.map((res=>(
                    <tr key={res.id}>
                        <td>{res.id}</td>
                        <td>{res.name}</td>
                        <td>{res.phone}</td>
                        <td>
                            <button>
                                <Link to="/create" >Create</Link>
                            </button>
                            <button>Read</button>
                            <button>Update</button>
                            <button>Delete</button>
                        </td>
                    </tr>                    
                )))
            }
        </tbody>
      </table>
    </div>
  )
}

export default Home
